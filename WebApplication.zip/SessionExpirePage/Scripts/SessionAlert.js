﻿
$(document).ready(function () {
            var t = 60;
            var prolongBool = false;

            var originURL = document.location.origin;
            var expireTime = 2;// <%= FormsAuthentication.Timeout.TotalMinutes %>;
    var userid = '@Session["UserID"]';
    alert(userid);
             // Dialog Counter
            var dialogCounter = function () {
        setTimeout(function () {
            $('#tickVar').text(t);
            t--;
            if (t <= 0 && prolongBool === false) {
                var originURL = document.location.origin;
                window.location.replace(originURL + "/SessionExpired.aspx");
                return;
            }
            else if (t <= 0) {
                return;
            }
            dialogCounter();
        }, 1000);
             }

            var refreshDialogTimer = function () {
        setTimeout(function () {
            $('#timeoutDialog').dialog('open');
        }, (expireTime * 1000 * 60 - (100 * 1000)));
             };

             refreshDialogTimer();

            $('#timeoutDialog').dialog({

        title: "Session Expiring!",
                 autoOpen: false,
                height: 200,
                width: 300,
                 modal: true,
                 buttons: {
        'Yes': function () {
        prolongBool = true;
                         $.post("http://localhost:44384/WebService.asmx/HelloWorld");
                       //  $.get("/KeepSessionAlive.ashx");

                         refreshDialogTimer();
                         $(this).dialog("close");
                     },
                     Cancel: function () {
                         var originURL = document.location.origin;
                         window.location.replace(originURL + "/timeout.aspx");
                     }
                 },
                 open: function () {
        prolongBool = false;
                     $('#tickVar').text(60);
                     t = 60;
                     dialogCounter();
                 }
             }); // end timeoutDialog
        }); //End page load

    //    function KeepSessionAlive() {
    //        debugger;
    //         1. Make request to server
    //        $.post("https://localhost:44344/RefreshSessionState.aspx");

    //         2. Schedule new request after 60000 miliseconds (1 minute)
    //        setInterval(KeepSessionAlive, 60000);
    //    }

    // Initial call of function
    //KeepSessionAlive();  
