﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SessionExpirePage
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SessionTimeOut.Value = "narasimha";
        }
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
          //  AutoRedirect();
        }

        public void AutoRedirect()
        {
            //int time = Session.Timeout - 2;

            //if (time == 1)
            //{
            //    int int_MilliSecondsTimeOut = (this.Session.Timeout * 60000);
            //    string str_Script = @"
            //   <script type='text/javascript'> 
            //       intervalset = window.setInterval('Redirect()'," +
            //               int_MilliSecondsTimeOut.ToString() + @");
            //       function Redirect()
            //       {
            //           window.location.href='/SessionExpired.aspx'; 
            //       }
            //   </script>";

            //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Redirect", str_Script);
            //}
        }
    }
}